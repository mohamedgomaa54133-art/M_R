/* =========================================================
   CHAT.JS
   PRIVATE CHAT — MOHAMED & RAHMA

   مسؤول عن:
   - قراءة وإرسال الرسائل النصية
   - Reply
   - Edit
   - Delete for me
   - Delete for everyone
   - Pin / Unpin
   - Read receipts ✓ / ✓✓
   - Emoji
   - Stickers
   - معلومات الطرف الآخر
   - قائمة الشات
   - تسجيل الخروج

   لا يحتوي على:
   - Upload
   - Audio recording
   - Presence
   - Firebase initialization
   - Auth initialization
========================================================= */


/* =========================================================
   01 — CHAT SETTINGS
========================================================= */

const CHAT_ID = "mohamed_rahma";

const messagesRef = db
    .collection("chats")
    .doc(CHAT_ID)
    .collection("messages");


/* =========================================================
   02 — VARIABLES
========================================================= */

let currentUser = null;
let currentUserProfile = null;

let otherUser = null;
let otherUserProfile = null;

let unsubscribeMessages = null;

let selectedMessageId = null;
let selectedMessageData = null;

let replyToMessage = null;
let editingMessageId = null;


/* =========================================================
   03 — DOM
========================================================= */

const messageForm =
    document.getElementById("messageForm");

const messageInput =
    document.getElementById("messageInput");

const messagesArea =
    document.getElementById("messagesArea");

const chatEmpty =
    document.getElementById("chatEmpty");

const sendMessageBtn =
    document.getElementById("sendMessageBtn");


/* =========================================================
   04 — EMOJI
========================================================= */

const emojiBtn =
    document.getElementById("emojiBtn");

const emojiPanel =
    document.getElementById("emojiPanel");

const emojiList =
    document.getElementById("emojiList");

const closeEmojiBtn =
    document.getElementById("closeEmojiBtn");


/* =========================================================
   05 — STICKERS
========================================================= */

const stickerBtn =
    document.getElementById("stickerBtn");

const stickerPanel =
    document.getElementById("stickerPanel");

const closeStickerBtn =
    document.getElementById("closeStickerBtn");

const stickerGrid =
    document.getElementById("stickerGrid");


/* =========================================================
   06 — REPLY
========================================================= */

const replyBar =
    document.getElementById("replyBar");

const replyBarName =
    document.getElementById("replyBarName");

const replyBarText =
    document.getElementById("replyBarText");

const cancelReplyBtn =
    document.getElementById("cancelReplyBtn");


/* =========================================================
   07 — CHAT HEADER
========================================================= */

const chatUserBtn =
    document.getElementById("chatUserBtn");

const chatUserName =
    document.getElementById("chatUserName");

const chatUserStatus =
    document.getElementById("chatUserStatus");

const chatUserPhoto =
    document.getElementById("chatUserPhoto");

const chatUserPhotoFallback =
    document.getElementById("chatUserPhotoFallback");

const onlineDot =
    document.getElementById("onlineDot");


/* =========================================================
   08 — USER INFO
========================================================= */

const userInfoOverlay =
    document.getElementById("userInfoOverlay");

const closeUserInfoBtn =
    document.getElementById("closeUserInfoBtn");

const popupUserName =
    document.getElementById("popupUserName");

const popupUserEmail =
    document.getElementById("popupUserEmail");

const popupUserStatus =
    document.getElementById("popupUserStatus");

const popupUserPhoto =
    document.getElementById("popupUserPhoto");

const popupUserFallback =
    document.getElementById("popupUserFallback");


/* =========================================================
   09 — MESSAGE ACTION MENU
========================================================= */

const messageActionOverlay =
    document.getElementById("messageActionOverlay");

const replyMessageBtn =
    document.getElementById("replyMessageBtn");

const editMessageBtn =
    document.getElementById("editMessageBtn");

const pinMessageBtn =
    document.getElementById("pinMessageBtn");

const deleteMessageBtn =
    document.getElementById("deleteMessageBtn");

const deleteForEveryoneBtn =
    document.getElementById("deleteForEveryoneBtn");

const cancelMessageActionBtn =
    document.getElementById("cancelMessageActionBtn");


/* =========================================================
   10 — DELETE CONFIRM
========================================================= */

const deleteConfirmOverlay =
    document.getElementById("deleteConfirmOverlay");

const cancelDeleteBtn =
    document.getElementById("cancelDeleteBtn");

const confirmDeleteBtn =
    document.getElementById("confirmDeleteBtn");


/* =========================================================
   11 — PINNED
========================================================= */

const pinnedBar =
    document.getElementById("pinnedBar");

const pinnedText =
    document.getElementById("pinnedText");

const closePinnedBtn =
    document.getElementById("closePinnedBtn");

const pinnedMenuBtn =
    document.getElementById("pinnedMenuBtn");


/* =========================================================
   12 — CHAT MENU
========================================================= */

const chatMenuBtn =
    document.getElementById("chatMenuBtn");

const chatMenuOverlay =
    document.getElementById("chatMenuOverlay");

const logoutBtn =
    document.getElementById("logoutBtn");

const closeChatMenuBtn =
    document.getElementById("closeChatMenuBtn");


/* =========================================================
   13 — START
========================================================= */

console.log("CHAT.JS STARTED");


/* =========================================================
   14 — CHECK FIREBASE
========================================================= */

if (
    typeof firebase === "undefined" ||
    typeof db === "undefined" ||
    typeof auth === "undefined"
) {

    console.error(
        "Firebase / Auth / Firestore غير جاهز."
    );

}


/* =========================================================
   15 — AUTH STATE
========================================================= */

auth.onAuthStateChanged(
    async function(user) {

        console.log(
            "CHAT AUTH:",
            user
                ? user.uid
                : "NO USER"
        );


        if (!user) {

            currentUser = null;

            window.location.replace(
                "index.html"
            );

            return;

        }


        /*
           الحساب المسجل حاليًا
           من Firebase Authentication.
        */

        currentUser = user;


        try {

            await loadCurrentUser();

            await findOtherUser();

            updateOtherUserUI();

            startMessagesListener();

        }

        catch (error) {

            console.error(
                "CHAT START ERROR:",
                error
            );

            console.error(
                "ERROR CODE:",
                error.code
            );

            console.error(
                "ERROR MESSAGE:",
                error.message
            );


            alert(
                "حدث خطأ أثناء فتح الشات.\n\n" +
                error.message
            );

        }

    }
);


/* =========================================================
   16 — LOAD CURRENT USER
========================================================= */

async function loadCurrentUser() {

    if (!currentUser) {

        throw new Error(
            "لم يتم العثور على الحساب الحالي."
        );

    }


    console.log(
        "CURRENT UID:",
        currentUser.uid
    );

    console.log(
        "CURRENT EMAIL:",
        currentUser.email
    );


    const userDoc =
        await db
            .collection("users")
            .doc(currentUser.uid)
            .get();


    if (!userDoc.exists) {

        console.warn(
            "Profile غير موجود للحساب الحالي."
        );


        currentUserProfile = {

            uid:
                currentUser.uid,

            email:
                currentUser.email || "",

            username:
                currentUser.displayName || "",

            displayName:
                currentUser.displayName || "",

            name:
                currentUser.displayName || "",

            photoUrl:
                currentUser.photoURL || ""

        };


        return;

    }


    currentUserProfile =
        userDoc.data() || {};


    /*
       نتأكد أن UID داخل الـ Profile
       مطابق للحساب المسجل.
    */

    currentUserProfile.uid =
        currentUser.uid;


    /*
       نستخدم Email Authentication
       إذا كان موجودًا.
    */

    if (!currentUserProfile.email) {

        currentUserProfile.email =
            currentUser.email || "";

    }


    console.log(
        "CURRENT PROFILE:",
        currentUserProfile
    );

}


/* =========================================================
   17 — FIND OTHER USER
========================================================= */

async function findOtherUser() {

    otherUser = null;

    otherUserProfile = null;


    const snapshot =
        await db
            .collection("users")
            .get();


    console.log(
        "TOTAL USERS:",
        snapshot.size
    );


    /*
       نبحث فقط عن User مختلف
       عن الحساب المسجل حاليًا.

       لا نستخدم email كمفتاح أساسي.
       الـ UID هو الأساس.
    */

    const otherDocs =
        snapshot.docs.filter(
            function(doc) {

                return (
                    doc.id !==
                    currentUser.uid
                );

            }
        );


    if (!otherDocs.length) {

        throw new Error(
            "لم يتم العثور على حساب الطرف الآخر في مجموعة users."
        );

    }


    /*
       في المشروع يوجد شخصان فقط،
       لذلك أول حساب مختلف
       هو الطرف الآخر.
    */

    const otherDoc =
        otherDocs[0];


    const data =
        otherDoc.data() || {};


    otherUser = {

        uid:
            otherDoc.id,

        ...data

    };


    otherUserProfile =
        data;


    console.log(
        "OTHER USER UID:",
        otherUser.uid
    );


    console.log(
        "OTHER USER PROFILE:",
        otherUserProfile
    );

}


/* =========================================================
   18 — USER NAME
========================================================= */

function getUserName(
    profile,
    fallbackUser
) {

    if (profile) {

        if (profile.username) {

            return String(
                profile.username
            );

        }


        if (profile.displayName) {

            return String(
                profile.displayName
            );

        }


        if (profile.name) {

            return String(
                profile.name
            );

        }

    }


    if (
        fallbackUser &&
        fallbackUser.displayName
    ) {

        return String(
            fallbackUser.displayName
        );

    }


    if (
        fallbackUser &&
        fallbackUser.email
    ) {

        return String(
            fallbackUser.email
        );

    }


    return "المستخدم";

}


/* =========================================================
   19 — USER PHOTO
========================================================= */

function getUserPhoto(
    profile,
    fallbackUser
) {

    if (profile) {

        return (
            profile.photoUrl ||
            profile.photoURL ||
            profile.photo ||
            ""
        );

    }


    if (fallbackUser) {

        return (
            fallbackUser.photoURL ||
            ""
        );

    }


    return "";

}


/* =========================================================
   20 — UPDATE HEADER
========================================================= */

function updateOtherUserUI() {

    if (!otherUser) {

        return;

    }


    const name =
        getUserName(
            otherUserProfile,
            otherUser
        );


    const email =
        otherUserProfile?.email ||
        otherUser.email ||
        "-";


    const photoUrl =
        getUserPhoto(
            otherUserProfile,
            otherUser
        );


    if (chatUserName) {

        chatUserName.textContent =
            name;

    }


    /*
       Presence يتم التعامل معه
       في presence.js فقط.
    */

    setUserPhoto(
        chatUserPhoto,
        chatUserPhotoFallback,
        photoUrl,
        name
    );


    if (popupUserName) {

        popupUserName.textContent =
            name;

    }


    if (popupUserEmail) {

        popupUserEmail.textContent =
            email;

    }


    setUserPhoto(
        popupUserPhoto,
        popupUserFallback,
        photoUrl,
        name
    );

}


/* =========================================================
   21 — SET USER PHOTO
========================================================= */

function setUserPhoto(
    image,
    fallback,
    url,
    name
) {

    if (!image || !fallback) {

        return;

    }


    if (url) {

        image.src =
            url;

        image.style.display =
            "block";

        fallback.style.display =
            "none";


        image.onerror =
            function() {

                image.style.display =
                    "none";

                fallback.textContent =
                    getInitial(name);

                fallback.style.display =
                    "flex";

            };

    }

    else {

        image.style.display =
            "none";

        fallback.textContent =
            getInitial(name);

        fallback.style.display =
            "flex";

    }

}


/* =========================================================
   22 — INITIAL
========================================================= */

function getInitial(name) {

    if (!name) {

        return "؟";

    }


    return String(name)
        .trim()
        .charAt(0)
        .toUpperCase();

}


/* =========================================================
   23 — MESSAGE LISTENER
========================================================= */

function startMessagesListener() {

    if (!currentUser) {

        return;

    }


    if (unsubscribeMessages) {

        unsubscribeMessages();

        unsubscribeMessages =
            null;

    }


    console.log(
        "START MESSAGE LISTENER"
    );


    unsubscribeMessages =
        messagesRef
            .orderBy(
                "createdAt",
                "asc"
            )
            .onSnapshot(

                async function(snapshot) {

                    const messages = [];


                    snapshot.forEach(
                        function(doc) {

                            const data =
                                doc.data() || {};


                            const hiddenFor =
                                data.hiddenFor ||
                                {};


                            /*
                               الرسالة مخفية
                               عند المستخدم الحالي.
                            */

                            if (
                                hiddenFor[
                                    currentUser.uid
                                ] === true
                            ) {

                                return;

                            }


                            messages.push({

                                id:
                                    doc.id,

                                ...data

                            });

                        }
                    );


                    renderAllMessages(
                        messages
                    );


                    loadPinnedMessage(
                        messages
                    );


                    await markIncomingMessagesAsRead(
                        messages
                    );

                },

                function(error) {

                    console.error(
                        "MESSAGES ERROR:",
                        error
                    );


                    if (
                        error.code ===
                        "permission-denied"
                    ) {

                        alert(
                            "Firebase رفض قراءة الرسائل.\n\n" +
                            "راجع Firestore Rules."
                        );

                    }

                }

            );

}


/* =========================================================
   24 — RENDER ALL
========================================================= */

function renderAllMessages(
    messages
) {

    if (!messagesArea) {

        return;

    }


    messagesArea.innerHTML =
        "";


    if (!messages.length) {

        showEmptyChat();

        return;

    }


    hideEmptyChat();


    messages.forEach(
        function(message) {

            renderMessage(
                message
            );

        }
    );


    scrollToBottom();

}


/* =========================================================
   25 — EMPTY CHAT
========================================================= */

function showEmptyChat() {

    if (!messagesArea) {

        return;

    }


    messagesArea.innerHTML =
        "";


    if (chatEmpty) {

        messagesArea.appendChild(
            chatEmpty
        );


        chatEmpty.style.display =
            "flex";

    }

}


function hideEmptyChat() {

    if (chatEmpty) {

        chatEmpty.style.display =
            "none";

    }

}


/* =========================================================
   26 — MARK READ
========================================================= */

async function markIncomingMessagesAsRead(
    messages
) {

    if (!currentUser) {

        return;

    }


    const batch =
        db.batch();


    let changed =
        false;


    messages.forEach(
        function(message) {

            /*
               لا نضع Read على رسائلنا.
            */

            if (
                message.senderId ===
                currentUser.uid
            ) {

                return;

            }


            if (
                message.deleted ===
                true
            ) {

                return;

            }


            const readBy =
                message.readBy ||
                {};


            if (
                readBy[
                    currentUser.uid
                ] === true
            ) {

                return;

            }


            batch.update(

                messagesRef.doc(
                    message.id
                ),

                {

                    [`readBy.${currentUser.uid}`]:
                        true,

                    readAt:
                        firebase.firestore
                            .FieldValue
                            .serverTimestamp()

                }

            );


            changed =
                true;

        }
    );


    if (!changed) {

        return;

    }


    try {

        await batch.commit();

    }

    catch (error) {

        console.error(
            "MARK READ ERROR:",
            error
        );

    }

}


/* =========================================================
   27 — SEND MESSAGE
========================================================= */

if (messageForm) {

    messageForm.addEventListener(
        "submit",
        async function(event) {

            event.preventDefault();


            if (!currentUser) {

                alert(
                    "لم يتم التعرف على الحساب."
                );

                return;

            }


            const text =
                messageInput
                    ? messageInput.value.trim()
                    : "";


            if (!text) {

                return;

            }


            /*
               EDIT
            */

            if (editingMessageId) {

                await editMessage(
                    text
                );

                return;

            }


            const messageData = {

                senderId:
                    currentUser.uid,

                senderName:
                    getUserName(
                        currentUserProfile,
                        currentUser
                    ),

                senderEmail:
                    currentUser.email ||
                    "",

                type:
                    "text",

                text:
                    text,

                createdAt:
                    firebase.firestore
                        .FieldValue
                        .serverTimestamp(),

                edited:
                    false,

                deleted:
                    false,

                pinned:
                    false,

                readBy: {

                    /*
                       المرسل قرأ رسالته.
                    */

                    [currentUser.uid]:
                        true

                },

                hiddenFor: {}

            };


            /*
               REPLY
            */

            if (replyToMessage) {

                messageData.replyTo = {

                    messageId:
                        replyToMessage.id,

                    senderId:
                        replyToMessage.senderId,

                    senderName:
                        replyToMessage.senderName ||
                        "",

                    text:
                        replyToMessage.text ||
                        ""

                };

            }


            try {

                await messagesRef.add(
                    messageData
                );


                if (messageInput) {

                    messageInput.value =
                        "";

                }


                clearReply();

                autoResizeTextarea();

                closePanels();

            }

            catch (error) {

                console.error(
                    "SEND MESSAGE ERROR:",
                    error
                );


                alert(
                    "تعذر إرسال الرسالة:\n" +
                    error.message
                );

            }

        }
    );

}


/* =========================================================
   28 — EDIT MESSAGE
========================================================= */

async function editMessage(
    text
) {

    if (
        !editingMessageId ||
        !currentUser
    ) {

        return;

    }


    try {

        const updateData = {

            text:
                text,

            edited:
                true,

            editedAt:
                firebase.firestore
                    .FieldValue
                    .serverTimestamp(),

            [`readBy.${currentUser.uid}`]:
                true

        };


        /*
           عند تعديل الرسالة:
           الطرف الآخر يعتبر النسخة
           الجديدة غير مقروءة.
        */

        if (
            otherUser &&
            otherUser.uid
        ) {

            updateData[
                `readBy.${otherUser.uid}`
            ] = false;

        }


        await messagesRef
            .doc(
                editingMessageId
            )
            .update(
                updateData
            );


        editingMessageId =
            null;


        if (messageInput) {

            messageInput.value =
                "";

        }


        updateSendMode();

        autoResizeTextarea();

    }

    catch (error) {

        console.error(
            "EDIT ERROR:",
            error
        );


        alert(
            "تعذر تعديل الرسالة:\n" +
            error.message
        );

    }

}


/* =========================================================
   29 — RENDER MESSAGE
========================================================= */

function renderMessage(
    message
) {

    if (
        !currentUser ||
        !messagesArea
    ) {

        return;

    }


    const wrapper =
        document.createElement("div");


    wrapper.className =
        "message-wrapper";


    wrapper.dataset.messageId =
        message.id;


    const isMine =
        message.senderId ===
        currentUser.uid;


    wrapper.classList.add(
        isMine
            ? "message-mine"
            : "message-other"
    );


    const bubble =
        document.createElement("div");


    bubble.className =
        "message-bubble";


    /*
       DELETED
    */

    if (message.deleted === true) {

        const deleted =
            document.createElement("span");


        deleted.className =
            "deleted-message";


        deleted.textContent =
            "تم حذف هذه الرسالة";


        bubble.appendChild(
            deleted
        );

    }

    else {

        /*
           REPLY
        */

        if (message.replyTo) {

            const reply =
                document.createElement("div");


            reply.className =
                "message-reply-preview";


            reply.dataset.replyToId =
                message.replyTo.messageId ||
                "";


            const replyName =
                document.createElement("strong");


            replyName.textContent =
                message.replyTo.senderName ||
                "رسالة";


            const replyText =
                document.createElement("span");


            replyText.textContent =
                getReplyPreviewText(
                    message.replyTo.text
                );


            reply.appendChild(
                replyName
            );


            reply.appendChild(
                replyText
            );


            reply.addEventListener(
                "click",
                function(event) {

                    event.stopPropagation();


                    jumpToOriginalMessage(
                        message.replyTo.messageId
                    );

                }
            );


            bubble.appendChild(
                reply
            );

        }


        /*
           TEXT
        */

        if (
            message.type ===
            "text"
        ) {

            const text =
                document.createElement("div");


            text.className =
                "message-text";


            text.textContent =
                message.text ||
                "";


            bubble.appendChild(
                text
            );

        }


        /*
           STICKER
        */

        if (
            message.type ===
            "sticker"
        ) {

            const sticker =
                document.createElement("div");


            sticker.className =
                "message-sticker";


            sticker.textContent =
                message.sticker ||
                "🙂";


            bubble.appendChild(
                sticker
            );

        }


        /*
           EDITED
        */

        if (message.edited) {

            const edited =
                document.createElement("small");


            edited.className =
                "message-edited";


            edited.textContent =
                "تم التعديل";


            bubble.appendChild(
                edited
            );

        }

    }


    /*
       FOOTER
    */

    const footer =
        document.createElement("div");


    footer.className =
        "message-footer";


    const time =
        document.createElement("span");


    time.className =
        "message-time";


    time.textContent =
        formatMessageTime(
            message.createdAt
        );


    footer.appendChild(
        time
    );


    /*
       CHECKS
    */

    if (isMine) {

        const checks =
            document.createElement("span");


        checks.className =
            "message-checks";


        const readBy =
            message.readBy ||
            {};


        const read =
            otherUser &&
            otherUser.uid
                ? readBy[
                    otherUser.uid
                  ] === true
                : false;


        /*
           ✓  = لم تُقرأ
           ✓✓ = تمت القراءة
        */

        checks.textContent =
            read
                ? "✓✓"
                : "✓";


        footer.appendChild(
            checks
        );

    }


    bubble.appendChild(
        footer
    );


    wrapper.appendChild(
        bubble
    );


    /*
       فتح قائمة الرسالة
    */

    bubble.addEventListener(
        "click",
        function() {

            openMessageActions(
                message
            );

        }
    );


    messagesArea.appendChild(
        wrapper
    );

}


/* =========================================================
   30 — REPLY PREVIEW
========================================================= */

function getReplyPreviewText(
    text
) {

    if (!text) {

        return "رسالة";

    }


    const clean =
        String(text)
            .replace(
                /\s+/g,
                " "
            )
            .trim();


    if (!clean) {

        return "رسالة";

    }


    if (
        clean.length >
        70
    ) {

        return (
            clean.substring(
                0,
                70
            ) +
            "..."
        );

    }


    return clean;

}


/* =========================================================
   31 — JUMP TO MESSAGE
========================================================= */

function jumpToOriginalMessage(
    messageId
) {

    if (
        !messageId ||
        !messagesArea
    ) {

        return;

    }


    const element =
        messagesArea.querySelector(
            `[data-message-id="${messageId}"]`
        );


    if (!element) {

        return;

    }


    element.scrollIntoView({

        behavior:
            "smooth",

        block:
            "center"

    });


    element.classList.add(
        "message-jump-highlight"
    );


    setTimeout(
        function() {

            element.classList.remove(
                "message-jump-highlight"
            );

        },
        1500
    );

}


/* =========================================================
   32 — REPLY
========================================================= */

function openReply(
    message
) {

    if (!message) {

        return;

    }


    replyToMessage =
        message;


    if (replyBar) {

        replyBar.style.display =
            "flex";

    }


    if (replyBarName) {

        replyBarName.textContent =
            message.senderName ||
            "الرد";

    }


    if (replyBarText) {

        replyBarText.textContent =
            message.deleted
                ? "تم حذف هذه الرسالة"
                : getReplyPreviewText(
                    message.text
                );

    }


    closeMessageActions();


    if (messageInput) {

        messageInput.focus();

    }

}


function clearReply() {

    replyToMessage =
        null;


    if (replyBar) {

        replyBar.style.display =
            "none";

    }


    if (replyBarName) {

        replyBarName.textContent =
            "الرد";

    }


    if (replyBarText) {

        replyBarText.textContent =
            "-";

    }

}


if (cancelReplyBtn) {

    cancelReplyBtn.addEventListener(
        "click",
        clearReply
    );

}


if (replyMessageBtn) {

    replyMessageBtn.addEventListener(
        "click",
        function() {

            if (selectedMessageData) {

                openReply(
                    selectedMessageData
                );

            }

        }
    );

}


/* =========================================================
   33 — MESSAGE ACTIONS
========================================================= */

function openMessageActions(
    message
) {

    if (
        !message ||
        !currentUser
    ) {

        return;

    }


    selectedMessageId =
        message.id;


    selectedMessageData =
        message;


    const isMine =
        message.senderId ===
        currentUser.uid;


    const deleted =
        message.deleted === true;


    /*
       EDIT
    */

    if (editMessageBtn) {

        editMessageBtn.style.display =
            (
                isMine &&
                !deleted &&
                message.type === "text"
            )
                ? "block"
                : "none";

    }


    /*
       DELETE FOR EVERYONE
    */

    if (deleteForEveryoneBtn) {

        deleteForEveryoneBtn.style.display =
            (
                isMine &&
                !deleted
            )
                ? "block"
                : "none";

    }


    /*
       PIN
    */

    if (pinMessageBtn) {

        if (!deleted) {

            pinMessageBtn.style.display =
                "block";


            pinMessageBtn.textContent =
                message.pinned === true
                    ? "📌 إلغاء تثبيت"
                    : "📌 تثبيت الرسالة";

        }

        else {

            pinMessageBtn.style.display =
                "none";

        }

    }


    /*
       DELETE FOR ME
    */

    if (deleteMessageBtn) {

        deleteMessageBtn.style.display =
            deleted
                ? "none"
                : "block";

    }


    if (messageActionOverlay) {

        messageActionOverlay.style.display =
            "flex";

    }

}


function closeMessageActions() {

    if (messageActionOverlay) {

        messageActionOverlay.style.display =
            "none";

    }

}


if (cancelMessageActionBtn) {

    cancelMessageActionBtn.addEventListener(
        "click",
        closeMessageActions
    );

}


if (messageActionOverlay) {

    messageActionOverlay.addEventListener(
        "click",
        function(event) {

            if (
                event.target ===
                messageActionOverlay
            ) {

                closeMessageActions();

            }

        }
    );

}


/* =========================================================
   34 — EDIT
========================================================= */

if (editMessageBtn) {

    editMessageBtn.addEventListener(
        "click",
        function() {

            if (selectedMessageData) {

                startEditMessage(
                    selectedMessageData
                );

            }

        }
    );

}


function startEditMessage(
    message
) {

    if (
        !message ||
        !currentUser ||
        !messageInput
    ) {

        return;

    }


    if (
        message.senderId !==
        currentUser.uid
    ) {

        return;

    }


    if (
        message.type !==
        "text"
    ) {

        return;

    }


    if (
        message.deleted ===
        true
    ) {

        return;

    }


    editingMessageId =
        message.id;


    messageInput.value =
        message.text ||
        "";


    updateSendMode();

    autoResizeTextarea();

    closeMessageActions();

    messageInput.focus();

}


/* =========================================================
   35 — CANCEL EDIT
========================================================= */

function cancelEditMessage() {

    editingMessageId =
        null;


    if (messageInput) {

        messageInput.value =
            "";

    }


    updateSendMode();

    autoResizeTextarea();

}


/* =========================================================
   36 — SEND MODE
========================================================= */

function updateSendMode() {

    if (!sendMessageBtn) {

        return;

    }


    if (editingMessageId) {

        sendMessageBtn.textContent =
            "✓";

        sendMessageBtn.title =
            "حفظ التعديل";

    }

    else {

        sendMessageBtn.textContent =
            "➤";

        sendMessageBtn.title =
            "إرسال";

    }

}


/* =========================================================
   37 — DELETE FOR ME
========================================================= */

if (deleteMessageBtn) {

    deleteMessageBtn.addEventListener(
        "click",
        function() {

            if (!selectedMessageData) {

                return;

            }


            closeMessageActions();


            if (deleteConfirmOverlay) {

                deleteConfirmOverlay.style.display =
                    "flex";

            }

        }
    );

}


if (cancelDeleteBtn) {

    cancelDeleteBtn.addEventListener(
        "click",
        function() {

            if (deleteConfirmOverlay) {

                deleteConfirmOverlay.style.display =
                    "none";

            }

        }
    );

}


/* =========================================================
   38 — CONFIRM DELETE FOR ME
========================================================= */

if (confirmDeleteBtn) {

    confirmDeleteBtn.addEventListener(
        "click",
        async function() {

            if (
                !selectedMessageId ||
                !currentUser
            ) {

                return;

            }


            try {

                await messagesRef
                    .doc(
                        selectedMessageId
                    )
                    .update({

                        [`hiddenFor.${currentUser.uid}`]:
                            true

                    });


                console.log(
                    "MESSAGE HIDDEN FOR CURRENT USER"
                );

            }

            catch (error) {

                console.error(
                    "DELETE FOR ME ERROR:",
                    error
                );


                alert(
                    "تعذر حذف الرسالة:\n" +
                    error.message
                );

            }


            if (deleteConfirmOverlay) {

                deleteConfirmOverlay.style.display =
                    "none";

            }


            selectedMessageId =
                null;


            selectedMessageData =
                null;

        }
    );

}


/* =========================================================
   39 — DELETE FOR EVERYONE
========================================================= */

if (deleteForEveryoneBtn) {

    deleteForEveryoneBtn.addEventListener(
        "click",
        async function() {

            const message =
                selectedMessageData;


            if (
                !message ||
                !currentUser
            ) {

                return;

            }


            if (
                message.senderId !==
                currentUser.uid
            ) {

                alert(
                    "يمكنك حذف رسائلك فقط لدى الجميع."
                );

                return;

            }


            if (
                message.deleted ===
                true
            ) {

                closeMessageActions();

                return;

            }


            closeMessageActions();


            try {

                await messagesRef
                    .doc(
                        message.id
                    )
                    .update({

                        deleted:
                            true,

                        text:
                            "",

                        deletedAt:
                            firebase.firestore
                                .FieldValue
                                .serverTimestamp(),

                        pinned:
                            false

                    });

            }

            catch (error) {

                console.error(
                    "DELETE EVERYONE ERROR:",
                    error
                );


                alert(
                    "تعذر حذف الرسالة لدى الجميع:\n" +
                    error.message
                );

            }


            selectedMessageId =
                null;


            selectedMessageData =
                null;

        }
    );

}


/* =========================================================
   40 — PIN
========================================================= */

if (pinMessageBtn) {

    pinMessageBtn.addEventListener(
        "click",
        async function() {

            const message =
                selectedMessageData;


            if (!message) {

                return;

            }


            if (
                message.deleted ===
                true
            ) {

                closeMessageActions();

                return;

            }


            const pinned =
                message.pinned === true;


            try {

                if (pinned) {

                    await messagesRef
                        .doc(
                            message.id
                        )
                        .update({

                            pinned:
                                false,

                            pinnedAt:
                                firebase.firestore
                                    .FieldValue
                                    .delete()

                        });

                }

                else {

                    await messagesRef
                        .doc(
                            message.id
                        )
                        .update({

                            pinned:
                                true,

                            pinnedAt:
                                firebase.firestore
                                    .FieldValue
                                    .serverTimestamp()

                        });

                }

            }

            catch (error) {

                console.error(
                    "PIN ERROR:",
                    error
                );


                alert(
                    pinned
                        ? "تعذر إلغاء تثبيت الرسالة."
                        : "تعذر تثبيت الرسالة."
                );

            }


            closeMessageActions();


            selectedMessageId =
                null;


            selectedMessageData =
                null;

        }
    );

}


/* =========================================================
   41 — PINNED MESSAGE
========================================================= */

function loadPinnedMessage(
    messages
) {

    if (
        !messages ||
        !messages.length
    ) {

        hidePinnedBar();

        return;

    }


    const pinned =
        messages.filter(
            function(message) {

                return (
                    message.pinned === true &&
                    message.deleted !== true
                );

            }
        );


    if (!pinned.length) {

        hidePinnedBar();

        return;

    }


    const latest =
        pinned[pinned.length - 1];


    if (pinnedBar) {

        pinnedBar.style.display =
            "flex";

    }


    if (pinnedText) {

        pinnedText.textContent =
            latest.text ||
            (
                latest.type === "sticker"
                    ? "استيكر"
                    : "رسالة"
            );

    }

}


function hidePinnedBar() {

    if (pinnedBar) {

        pinnedBar.style.display =
            "none";

    }


    if (pinnedText) {

        pinnedText.textContent =
            "-";

    }

}


if (closePinnedBtn) {

    closePinnedBtn.addEventListener(
        "click",
        hidePinnedBar
    );

}


if (pinnedMenuBtn) {

    pinnedMenuBtn.addEventListener(
        "click",
        function() {

            if (!messagesArea) {

                return;

            }


            const pinned =
                messagesArea.querySelector(
                    ".message-wrapper"
                );


            if (pinned) {

                pinned.scrollIntoView({

                    behavior:
                        "smooth",

                    block:
                        "center"

                });

            }

        }

    );

}


/* =========================================================
   42 — FORMAT TIME
========================================================= */

function formatMessageTime(
    timestamp
) {

    if (!timestamp) {

        return "";

    }


    try {

        if (
            typeof timestamp.toDate !==
            "function"
        ) {

            return "";

        }


        return timestamp
            .toDate()
            .toLocaleTimeString(
                "ar-EG",
                {

                    hour:
                        "2-digit",

                    minute:
                        "2-digit"

                }
            );

    }

    catch (error) {

        return "";

    }

}


/* =========================================================
   43 — SCROLL
========================================================= */

function scrollToBottom() {

    if (!messagesArea) {

        return;

    }


    messagesArea.scrollTop =
        messagesArea.scrollHeight;

}


/* =========================================================
   44 — TEXTAREA
========================================================= */

if (messageInput) {

    messageInput.addEventListener(
        "input",
        autoResizeTextarea
    );

}


function autoResizeTextarea() {

    if (!messageInput) {

        return;

    }


    messageInput.style.height =
        "auto";


    messageInput.style.height =
        Math.min(
            messageInput.scrollHeight,
            140
        ) + "px";

}


/* =========================================================
   45 — ENTER TO SEND
========================================================= */

if (messageInput) {

    messageInput.addEventListener(
        "keydown",
        function(event) {

            if (
                event.key === "Enter" &&
                !event.shiftKey
            ) {

                event.preventDefault();


                if (messageForm) {

                    messageForm.requestSubmit();

                }

            }

        }
    );

}


/* =========================================================
   46 — EMOJI
========================================================= */

if (emojiBtn && emojiPanel) {

    emojiBtn.addEventListener(
        "click",
        function(event) {

            event.stopPropagation();


            const isOpen =
                emojiPanel.style.display ===
                "block";


            closePanels();


            emojiPanel.style.display =
                isOpen
                    ? "none"
                    : "block";

        }
    );

}


if (closeEmojiBtn) {

    closeEmojiBtn.addEventListener(
        "click",
        function() {

            if (emojiPanel) {

                emojiPanel.style.display =
                    "none";

            }

        }
    );

}


/* =========================================================
   47 — PREPARE EMOJIS
========================================================= */

function prepareEmojiList() {

    if (!emojiList) {

        return;

    }


    const emojis =
        emojiList.textContent
            .trim()
            .split(/\s+/)
            .filter(Boolean);


    emojiList.innerHTML =
        "";


    emojis.forEach(
        function(emoji) {

            const button =
                document.createElement(
                    "button"
                );


            button.type =
                "button";


            button.className =
                "emoji-item";


            button.textContent =
                emoji;


            button.addEventListener(
                "click",
                function(event) {

                    event.preventDefault();

                    event.stopPropagation();


                    insertAtCursor(
                        messageInput,
                        emoji
                    );


                    if (messageInput) {

                        messageInput.focus();

                    }


                    autoResizeTextarea();

                }
            );


            emojiList.appendChild(
                button
            );

        }
    );

}


prepareEmojiList();


/* =========================================================
   48 — STICKERS
========================================================= */

if (stickerBtn) {

    stickerBtn.addEventListener(
        "click",
        function(event) {

            event.stopPropagation();


            if (!stickerPanel) {

                return;

            }


            const isOpen =
                stickerPanel.style.display ===
                "block";


            closePanels();


            stickerPanel.style.display =
                isOpen
                    ? "none"
                    : "block";

        }
    );

}


if (closeStickerBtn) {

    closeStickerBtn.addEventListener(
        "click",
        function() {

            if (stickerPanel) {

                stickerPanel.style.display =
                    "none";

            }

        }
    );

}


/* =========================================================
   49 — SEND STICKER
========================================================= */

if (stickerGrid) {

    stickerGrid.addEventListener(
        "click",
        async function(event) {

            const item =
                event.target.closest(
                    ".sticker-item"
                );


            if (!item) {

                return;

            }


            const sticker =
                item.dataset.sticker;


            if (
                !sticker ||
                !currentUser
            ) {

                return;

            }


            try {

                await messagesRef.add({

                    senderId:
                        currentUser.uid,

                    senderName:
                        getUserName(
                            currentUserProfile,
                            currentUser
                        ),

                    senderEmail:
                        currentUser.email ||
                        "",

                    type:
                        "sticker",

                    sticker:
                        sticker,

                    text:
                        "",

                    createdAt:
                        firebase.firestore
                            .FieldValue
                            .serverTimestamp(),

                    edited:
                        false,

                    deleted:
                        false,

                    pinned:
                        false,

                    readBy: {

                        [currentUser.uid]:
                            true

                    },

                    hiddenFor: {}

                });


                closePanels();

            }

            catch (error) {

                console.error(
                    "STICKER ERROR:",
                    error
                );


                alert(
                    "تعذر إرسال الاستيكر."
                );

            }

        }
    );

}


/* =========================================================
   50 — INSERT AT CURSOR
========================================================= */

function insertAtCursor(
    textarea,
    text
) {

    if (!textarea) {

        return;

    }


    const start =
        textarea.selectionStart || 0;


    const end =
        textarea.selectionEnd || 0;


    const value =
        textarea.value;


    textarea.value =
        value.substring(
            0,
            start
        ) +
        text +
        value.substring(
            end
        );


    const cursor =
        start +
        text.length;


    textarea.selectionStart =
        cursor;


    textarea.selectionEnd =
        cursor;

}


/* =========================================================
   51 — CLOSE PANELS
========================================================= */

function closePanels() {

    if (emojiPanel) {

        emojiPanel.style.display =
            "none";

    }


    if (stickerPanel) {

        stickerPanel.style.display =
            "none";

    }

}


/* =========================================================
   52 — INPUT FOCUS
========================================================= */

if (messageInput) {

    messageInput.addEventListener(
        "focus",
        function() {

            closePanels();

        }
    );

}


/* =========================================================
   53 — USER INFO
========================================================= */

if (chatUserBtn) {

    chatUserBtn.addEventListener(
        "click",
        function() {

            if (
                !otherUserProfile &&
                !otherUser
            ) {

                return;

            }


            if (userInfoOverlay) {

                userInfoOverlay.style.display =
                    "flex";

            }

        }
    );

}


if (closeUserInfoBtn) {

    closeUserInfoBtn.addEventListener(
        "click",
        function() {

            if (userInfoOverlay) {

                userInfoOverlay.style.display =
                    "none";

            }

        }
    );

}


if (userInfoOverlay) {

    userInfoOverlay.addEventListener(
        "click",
        function(event) {

            if (
                event.target ===
                userInfoOverlay
            ) {

                userInfoOverlay.style.display =
                    "none";

            }

        }
    );

}


/* =========================================================
   54 — CHAT MENU
========================================================= */

if (chatMenuBtn) {

    chatMenuBtn.addEventListener(
        "click",
        function(event) {

            event.stopPropagation();


            if (chatMenuOverlay) {

                chatMenuOverlay.style.display =
                    "flex";

            }

        }
    );

}


if (closeChatMenuBtn) {

    closeChatMenuBtn.addEventListener(
        "click",
        function() {

            if (chatMenuOverlay) {

                chatMenuOverlay.style.display =
                    "none";

            }

        }
    );

}


if (chatMenuOverlay) {

    chatMenuOverlay.addEventListener(
        "click",
        function(event) {

            if (
                event.target ===
                chatMenuOverlay
            ) {

                chatMenuOverlay.style.display =
                    "none";

            }

        }
    );

}


/* =========================================================
   55 — LOGOUT
========================================================= */

if (logoutBtn) {

    logoutBtn.addEventListener(
        "click",
        async function() {

            try {

                await auth.signOut();


                window.location.replace(
                    "index.html"
                );

            }

            catch (error) {

                console.error(
                    "LOGOUT ERROR:",
                    error
                );


                alert(
                    "تعذر تسجيل الخروج."
                );

            }

        }
    );

}


/* =========================================================
   56 — GLOBAL CLICK
========================================================= */

document.addEventListener(
    "click",
    function(event) {

        /*
           Emoji
        */

        if (
            emojiPanel &&
            emojiBtn &&
            emojiPanel.style.display ===
                "block" &&
            !emojiPanel.contains(
                event.target
            ) &&
            event.target !== emojiBtn
        ) {

            emojiPanel.style.display =
                "none";

        }


        /*
           Sticker
        */

        if (
            stickerPanel &&
            stickerBtn &&
            stickerPanel.style.display ===
                "block" &&
            !stickerPanel.contains(
                event.target
            ) &&
            event.target !== stickerBtn
        ) {

            stickerPanel.style.display =
                "none";

        }

    }
);


/* =========================================================
   57 — ESCAPE
========================================================= */

document.addEventListener(
    "keydown",
    function(event) {

        if (
            event.key !==
            "Escape"
        ) {

            return;

        }


        closeMessageActions();


        if (deleteConfirmOverlay) {

            deleteConfirmOverlay.style.display =
                "none";

        }


        if (userInfoOverlay) {

            userInfoOverlay.style.display =
                "none";

        }


        if (chatMenuOverlay) {

            chatMenuOverlay.style.display =
                "none";

        }


        closePanels();

    }
);


/* =========================================================
   58 — INITIAL UI
========================================================= */

updateSendMode();

autoResizeTextarea();


console.log(
    "CHAT.JS READY"
);


/* =========================================================
   END OF CHAT.JS
========================================================= */