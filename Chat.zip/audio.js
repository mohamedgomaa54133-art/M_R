/* =========================================================
   AUDIO.JS
   VOICE RECORDING SYSTEM
   SUPABASE + FIRESTORE
   START OF FILE
========================================================= */


/* =========================================================
   START — SUPABASE CONFIG
========================================================= */

const AUDIO_SUPABASE_URL =
    "https://qmigyzxkvrodnfyvjkbr.supabase.co";

const AUDIO_SUPABASE_KEY =
    "sb_publishable_BfnmEqlXE1YpUJnjP__JvQ_-nLQiP4a";

const audioSupabase =
    window.supabase.createClient(
        AUDIO_SUPABASE_URL,
        AUDIO_SUPABASE_KEY
    );


/* =========================================================
   END — SUPABASE CONFIG
========================================================= */


/* =========================================================
   START — ELEMENTS
========================================================= */

const voiceRecordingBar =
    document.getElementById("voiceRecordingBar");

const recordBtn =
    document.getElementById("recordBtn");

const cancelRecordingBtn =
    document.getElementById("cancelRecordingBtn");

const sendRecordingBtn =
    document.getElementById("sendRecordingBtn");

const recordingTime =
    document.getElementById("recordingTime");


/* =========================================================
   END — ELEMENTS
========================================================= */


/* =========================================================
   START — STATE
========================================================= */

let audioMediaRecorder = null;

let audioChunks = [];

let recordedAudioBlob = null;

let audioStream = null;

let audioRecordingTimer = null;

let audioRecordingSeconds = 0;

let audioIsRecording = false;

let audioIsUploading = false;


/* =========================================================
   END — STATE
========================================================= */


/* =========================================================
   START — RECORD BUTTON
========================================================= */

if (recordBtn) {

    recordBtn.addEventListener(
        "click",
        async function () {

            if (audioIsRecording) {
                return;
            }

            await startAudioRecording();

        }
    );

}


/* =========================================================
   END — RECORD BUTTON
========================================================= */


/* =========================================================
   START — START RECORDING
========================================================= */

async function startAudioRecording() {

    if (
        !navigator.mediaDevices ||
        !navigator.mediaDevices.getUserMedia
    ) {

        showAudioMessage(
            "المتصفح لا يدعم تسجيل الصوت."
        );

        return;
    }


    if (
        typeof MediaRecorder ===
        "undefined"
    ) {

        showAudioMessage(
            "جهازك لا يدعم تسجيل الصوت."
        );

        return;
    }


    const user =
        auth.currentUser;


    if (!user) {

        showAudioMessage(
            "يجب تسجيل الدخول أولًا."
        );

        return;
    }


    try {

        audioStream =
            await navigator.mediaDevices.getUserMedia(
                {
                    audio: {
                        echoCancellation: true,
                        noiseSuppression: true,
                        autoGainControl: true
                    }
                }
            );


        audioChunks = [];

        recordedAudioBlob = null;

        audioRecordingSeconds = 0;


        /* ---------------------------------------------
           SELECT BEST AUDIO FORMAT
        --------------------------------------------- */

        let mimeType = "";


        const supportedTypes = [

            "audio/webm;codecs=opus",

            "audio/webm",

            "audio/ogg;codecs=opus",

            "audio/mp4"

        ];


        for (
            const type of supportedTypes
        ) {

            if (
                MediaRecorder.isTypeSupported(
                    type
                )
            ) {

                mimeType = type;

                break;
            }

        }


        /* ---------------------------------------------
           CREATE MEDIA RECORDER
        --------------------------------------------- */

        if (mimeType) {

            audioMediaRecorder =
                new MediaRecorder(
                    audioStream,
                    {
                        mimeType: mimeType
                    }
                );

        } else {

            audioMediaRecorder =
                new MediaRecorder(
                    audioStream
                );

        }


        /* ---------------------------------------------
           DATA AVAILABLE
        --------------------------------------------- */

        audioMediaRecorder.addEventListener(
            "dataavailable",
            function (event) {

                if (
                    event.data &&
                    event.data.size > 0
                ) {

                    audioChunks.push(
                        event.data
                    );

                }

            }
        );


        /* ---------------------------------------------
           RECORDING STOPPED
        --------------------------------------------- */

        audioMediaRecorder.addEventListener(
            "stop",
            function () {

                if (
                    audioChunks.length === 0
                ) {

                    return;
                }


                const type =
                    audioMediaRecorder.mimeType ||
                    "audio/webm";


                recordedAudioBlob =
                    new Blob(
                        audioChunks,
                        {
                            type: type
                        }
                    );

            }
        );


        /* ---------------------------------------------
           START
        --------------------------------------------- */

        audioMediaRecorder.start(250);

        audioIsRecording = true;

        showRecordingBar();

        startRecordingTimer();


    } catch (error) {

        console.error(
            "AUDIO MICROPHONE ERROR:",
            error
        );


        if (audioStream) {

            audioStream
                .getTracks()
                .forEach(
                    function (track) {

                        track.stop();

                    }
                );

        }


        audioStream = null;

        audioMediaRecorder = null;

        audioIsRecording = false;


        showAudioMessage(
            "لم نتمكن من الوصول إلى الميكروفون. اسمح للموقع باستخدام الميكروفون."
        );

    }

}


/* =========================================================
   END — START RECORDING
========================================================= */


/* =========================================================
   START — STOP RECORDING
========================================================= */

function stopAudioRecording() {

    if (
        !audioMediaRecorder ||
        !audioIsRecording
    ) {

        return;
    }


    try {

        audioMediaRecorder.stop();

    } catch (error) {

        console.error(
            "AUDIO STOP ERROR:",
            error
        );

    }


    audioIsRecording = false;

    stopRecordingTimer();


    if (audioStream) {

        audioStream
            .getTracks()
            .forEach(
                function (track) {

                    track.stop();

                }
            );

    }


    audioStream = null;

}


/* =========================================================
   END — STOP RECORDING
========================================================= */


/* =========================================================
   START — CANCEL RECORDING
========================================================= */

if (cancelRecordingBtn) {

    cancelRecordingBtn.addEventListener(
        "click",
        function () {

            cancelAudioRecording();

        }
    );

}


function cancelAudioRecording() {

    if (
        audioMediaRecorder &&
        audioIsRecording
    ) {

        try {

            audioMediaRecorder.stop();

        } catch (error) {

            console.error(
                "CANCEL AUDIO ERROR:",
                error
            );

        }

    }


    audioIsRecording = false;

    stopRecordingTimer();


    if (audioStream) {

        audioStream
            .getTracks()
            .forEach(
                function (track) {

                    track.stop();

                }
            );

    }


    audioStream = null;

    audioChunks = [];

    recordedAudioBlob = null;

    audioMediaRecorder = null;


    hideRecordingBar();

}


/* =========================================================
   END — CANCEL RECORDING
========================================================= */


/* =========================================================
   START — SEND BUTTON
========================================================= */

if (sendRecordingBtn) {

    sendRecordingBtn.addEventListener(
        "click",
        async function () {

            await sendRecordedAudio();

        }
    );

}


/* =========================================================
   END — SEND BUTTON
========================================================= */


/* =========================================================
   START — SEND AUDIO
========================================================= */

async function sendRecordedAudio() {

    if (audioIsUploading) {
        return;
    }


    /* ---------------------------------------------
       STOP FIRST IF STILL RECORDING
    --------------------------------------------- */

    if (audioIsRecording) {

        stopAudioRecording();

        await wait(400);

    }


    if (
        !recordedAudioBlob ||
        recordedAudioBlob.size === 0
    ) {

        showAudioMessage(
            "لا يوجد تسجيل صوتي لإرساله."
        );

        return;
    }


    const user =
        auth.currentUser;


    if (!user) {

        showAudioMessage(
            "يجب تسجيل الدخول أولًا."
        );

        return;
    }


    audioIsUploading = true;

    sendRecordingBtn.disabled = true;


    try {

        showAudioMessage(
            "جاري رفع التسجيل..."
        );


        /* ---------------------------------------------
           FILE TYPE
        --------------------------------------------- */

        const mimeType =
            recordedAudioBlob.type ||
            "audio/webm";


        const extension =
            getAudioExtension(
                mimeType
            );


        /* ---------------------------------------------
           UNIQUE FILE PATH
        --------------------------------------------- */

        const filePath =
            `audio/${user.uid}/${Date.now()}_${randomAudioString(12)}.${extension}`;


        /* ---------------------------------------------
           UPLOAD SUPABASE
        --------------------------------------------- */

        const {
            error: uploadError
        } =
            await audioSupabase
                .storage
                .from("chat")
                .upload(
                    filePath,
                    recordedAudioBlob,
                    {
                        cacheControl: "3600",
                        upsert: false,
                        contentType: mimeType
                    }
                );


        if (uploadError) {

            console.error(
                "SUPABASE AUDIO UPLOAD ERROR:",
                uploadError
            );

            throw uploadError;
        }


        /* ---------------------------------------------
           PUBLIC URL
        --------------------------------------------- */

        const {
            data: publicData
        } =
            audioSupabase
                .storage
                .from("chat")
                .getPublicUrl(
                    filePath
                );


        const audioUrl =
            publicData &&
            publicData.publicUrl;


        if (!audioUrl) {

            throw new Error(
                "AUDIO_PUBLIC_URL_NOT_FOUND"
            );

        }


        /* ---------------------------------------------
           DURATION
        --------------------------------------------- */

        const duration =
            await getAudioDuration(
                recordedAudioBlob
            );


        /* ---------------------------------------------
           MESSAGE DATA
        --------------------------------------------- */

        const messageData = {

            uid: user.uid,

            senderId: user.uid,

            text: "",

            type: "audio",

            audioUrl: audioUrl,

            audioPath: filePath,

            mimeType: mimeType,

            fileSize:
                recordedAudioBlob.size,

            duration: duration,

            viewOnce: false,

            opened: false,

            createdAt:
                firebase.firestore
                    .FieldValue
                    .serverTimestamp()

        };


        /* ---------------------------------------------
           SEND TO CHAT.JS
        --------------------------------------------- */

        if (
            typeof window.saveChatMessage ===
            "function"
        ) {

            await window.saveChatMessage(
                messageData
            );

        } else {

            await db
                .collection("messages")
                .add(
                    messageData
                );

        }


        /* ---------------------------------------------
           CLEAR
        --------------------------------------------- */

        audioChunks = [];

        recordedAudioBlob = null;

        audioMediaRecorder = null;

        hideRecordingBar();


        showAudioMessage(
            "تم إرسال التسجيل ✓"
        );


    } catch (error) {

        console.error(
            "SEND AUDIO ERROR:",
            error
        );


        showAudioMessage(
            "تعذر إرسال التسجيل الصوتي."
        );


    } finally {

        audioIsUploading = false;

        sendRecordingBtn.disabled = false;

    }

}


/* =========================================================
   END — SEND AUDIO
========================================================= */


/* =========================================================
   START — TIMER
========================================================= */

function startRecordingTimer() {

    stopRecordingTimer();

    updateRecordingTime();


    audioRecordingTimer =
        setInterval(
            function () {

                audioRecordingSeconds++;

                updateRecordingTime();

            },
            1000
        );

}


function stopRecordingTimer() {

    if (audioRecordingTimer) {

        clearInterval(
            audioRecordingTimer
        );

        audioRecordingTimer = null;

    }

}


function updateRecordingTime() {

    if (!recordingTime) {
        return;
    }


    const minutes =
        Math.floor(
            audioRecordingSeconds / 60
        );


    const seconds =
        audioRecordingSeconds % 60;


    recordingTime.textContent =
        String(minutes).padStart(
            2,
            "0"
        ) +
        ":" +
        String(seconds).padStart(
            2,
            "0"
        );

}


/* =========================================================
   END — TIMER
========================================================= */


/* =========================================================
   START — RECORDING BAR
========================================================= */

function showRecordingBar() {

    if (!voiceRecordingBar) {
        return;
    }


    voiceRecordingBar.style.display =
        "flex";


    if (recordBtn) {

        recordBtn.style.display =
            "none";

    }

}


function hideRecordingBar() {

    if (voiceRecordingBar) {

        voiceRecordingBar.style.display =
            "none";

    }


    if (recordBtn) {

        recordBtn.style.display =
            "flex";

    }


    if (recordingTime) {

        recordingTime.textContent =
            "00:00";

    }

}


/* =========================================================
   END — RECORDING BAR
========================================================= */


/* =========================================================
   START — AUDIO DURATION
========================================================= */

function getAudioDuration(
    blob
) {

    return new Promise(
        function (resolve) {

            const audio =
                document.createElement(
                    "audio"
                );


            const url =
                URL.createObjectURL(
                    blob
                );


            audio.preload =
                "metadata";


            audio.onloadedmetadata =
                function () {

                    const duration =
                        Number.isFinite(
                            audio.duration
                        )
                            ? Math.round(
                                audio.duration
                            )
                            : 0;


                    URL.revokeObjectURL(
                        url
                    );


                    resolve(
                        duration
                    );

                };


            audio.onerror =
                function () {

                    URL.revokeObjectURL(
                        url
                    );


                    resolve(0);

                };


            audio.src = url;

        }
    );

}


/* =========================================================
   END — AUDIO DURATION
========================================================= */


/* =========================================================
   START — AUDIO EXTENSION
========================================================= */

function getAudioExtension(
    mimeType
) {

    const type =
        String(
            mimeType || ""
        ).toLowerCase();


    if (
        type.includes("mp4")
    ) {

        return "m4a";

    }


    if (
        type.includes("ogg")
    ) {

        return "ogg";

    }


    if (
        type.includes("mpeg")
    ) {

        return "mp3";

    }


    if (
        type.includes("wav")
    ) {

        return "wav";

    }


    return "webm";

}


/* =========================================================
   END — AUDIO EXTENSION
========================================================= */


/* =========================================================
   START — RANDOM STRING
========================================================= */

function randomAudioString(
    length
) {

    const chars =
        "abcdefghijklmnopqrstuvwxyz0123456789";


    let result = "";


    for (
        let i = 0;
        i < length;
        i++
    ) {

        result +=
            chars.charAt(
                Math.floor(
                    Math.random() *
                    chars.length
                )
            );

    }


    return result;

}


/* =========================================================
   END — RANDOM STRING
========================================================= */


/* =========================================================
   START — WAIT
========================================================= */

function wait(
    milliseconds
) {

    return new Promise(
        function (resolve) {

            setTimeout(
                resolve,
                milliseconds
            );

        }
    );

}


/* =========================================================
   END — WAIT
========================================================= */


/* =========================================================
   START — AUDIO TOAST
========================================================= */

function showAudioMessage(
    message
) {

    let toast =
        document.getElementById(
            "audioToast"
        );


    if (!toast) {

        toast =
            document.createElement(
                "div"
            );


        toast.id =
            "audioToast";


        toast.style.position =
            "fixed";

        toast.style.left =
            "50%";

        toast.style.bottom =
            "90px";

        toast.style.transform =
            "translateX(-50%)";

        toast.style.zIndex =
            "99999";

        toast.style.padding =
            "10px 18px";

        toast.style.borderRadius =
            "14px";

        toast.style.background =
            "rgba(20,20,25,.95)";

        toast.style.color =
            "#fff";

        toast.style.fontSize =
            "14px";

        toast.style.boxShadow =
            "0 8px 30px rgba(0,0,0,.35)";

        toast.style.whiteSpace =
            "nowrap";


        document.body.appendChild(
            toast
        );

    }


    toast.textContent =
        message;


    toast.style.display =
        "block";


    clearTimeout(
        toast._timer
    );


    toast._timer =
        setTimeout(
            function () {

                toast.style.display =
                    "none";

            },
            2500
        );

}


/* =========================================================
   END — AUDIO TOAST
========================================================= */


/* =========================================================
   AUDIO.JS
   END OF FILE
========================================================= */