/* =========================================================
   REACTION.JS
   Long Press Reactions
   ❤️ 🫡 🙂 🙃 🫂 🫶
========================================================= */

(function () {

    "use strict";

    const reactionBar =
        document.getElementById("reactionBar");

    const reactionButtons =
        reactionBar
            ? reactionBar.querySelectorAll(".reaction-btn")
            : [];

    let selectedMessageId = null;
    let pressTimer = null;

    const messagesRef =
        db
            .collection("chats")
            .doc("mohamed_rahma")
            .collection("messages");


    /* =====================================================
       CREATE REACTION BAR
    ===================================================== */

    function createReactionBar() {

        if (reactionBar) {
            return;
        }

        const bar =
            document.createElement("div");

        bar.id =
            "reactionBar";

        bar.className =
            "reaction-bar";

        bar.style.display =
            "none";

        const reactions = [
            "❤️",
            "🫡",
            "🙂",
            "🙃",
            "🫂",
            "🫶"
        ];

        reactions.forEach(function (reaction) {

            const button =
                document.createElement("button");

            button.type =
                "button";

            button.className =
                "reaction-btn";

            button.textContent =
                reaction;

            button.dataset.reaction =
                reaction;

            button.addEventListener(
                "click",
                function (event) {

                    event.stopPropagation();

                    sendReaction(
                        reaction
                    );

                }
            );

            bar.appendChild(button);

        });

        document.body.appendChild(bar);

    }


    /* =====================================================
       SHOW REACTION BAR
    ===================================================== */

    function showReactionBar(
        messageElement,
        messageId
    ) {

        const bar =
            document.getElementById(
                "reactionBar"
            );

        if (!bar) {
            return;
        }

        selectedMessageId =
            messageId;

        bar.style.display =
            "flex";

        const rect =
            messageElement.getBoundingClientRect();

        let top =
            rect.top - 60;

        let left =
            rect.left +
            (rect.width / 2) -
            120;

        if (top < 10) {
            top =
                rect.bottom + 10;
        }

        if (left < 10) {
            left = 10;
        }

        if (
            left +
            bar.offsetWidth >
            window.innerWidth - 10
        ) {

            left =
                window.innerWidth -
                bar.offsetWidth -
                10;

        }

        bar.style.position =
            "fixed";

        bar.style.top =
            top + "px";

        bar.style.left =
            left + "px";

    }


    /* =====================================================
       HIDE REACTION BAR
    ===================================================== */

    function hideReactionBar() {

        const bar =
            document.getElementById(
                "reactionBar"
            );

        if (!bar) {
            return;
        }

        bar.style.display =
            "none";

        selectedMessageId =
            null;

    }


    /* =====================================================
       SEND REACTION
    ===================================================== */

    async function sendReaction(
        reaction
    ) {

        if (
            !selectedMessageId ||
            !auth.currentUser
        ) {

            return;

        }

        const uid =
            auth.currentUser.uid;

        try {

            const messageRef =
                messagesRef.doc(
                    selectedMessageId
                );

            await messageRef.update({

                [`reactions.${uid}`]:
                    reaction

            });

            hideReactionBar();

        }

        catch (error) {

            console.error(
                "REACTION ERROR:",
                error
            );

            alert(
                "تعذر إضافة التفاعل."
            );

        }

    }


    /* =====================================================
       LONG PRESS
    ===================================================== */

    function startLongPress(
        event
    ) {

        const bubble =
            event.target.closest(
                ".message-bubble"
            );

        if (!bubble) {
            return;
        }

        const wrapper =
            bubble.closest(
                ".message-wrapper"
            );

        if (!wrapper) {
            return;
        }

        const messageId =
            wrapper.dataset.messageId;

        if (!messageId) {
            return;
        }

        pressTimer =
            setTimeout(
                function () {

                    showReactionBar(
                        bubble,
                        messageId
                    );

                },
                550
            );

    }


    function cancelLongPress() {

        if (pressTimer) {

            clearTimeout(
                pressTimer
            );

            pressTimer =
                null;

        }

    }


    /* =====================================================
       EVENTS
    ===================================================== */

    document.addEventListener(
        "touchstart",
        startLongPress,
        {
            passive: true
        }
    );

    document.addEventListener(
        "touchend",
        cancelLongPress
    );

    document.addEventListener(
        "touchmove",
        cancelLongPress
    );


    document.addEventListener(
        "mousedown",
        startLongPress
    );

    document.addEventListener(
        "mouseup",
        cancelLongPress
    );

    document.addEventListener(
        "mouseleave",
        cancelLongPress
    );


    /* =====================================================
       CLOSE WHEN CLICKING OUTSIDE
    ===================================================== */

    document.addEventListener(
        "click",
        function (event) {

            const bar =
                document.getElementById(
                    "reactionBar"
                );

            if (!bar) {
                return;
            }

            if (
                bar.style.display === "none"
            ) {
                return;
            }

            if (
                !bar.contains(
                    event.target
                )
            ) {

                hideReactionBar();

            }

        }
    );


    /* =====================================================
       ESC
    ===================================================== */

    document.addEventListener(
        "keydown",
        function (event) {

            if (
                event.key === "Escape"
            ) {

                hideReactionBar();

            }

        }
    );


    /* =====================================================
       START
    ===================================================== */

    createReactionBar();

    console.log(
        "REACTION.JS READY ❤️"
    );

})();