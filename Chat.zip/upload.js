/* =========================================================
   UPLOAD.JS
   IMAGE / VIDEO / VIEW ONCE UPLOAD SYSTEM
   START OF FILE
========================================================= */


/* =========================================================
   START — SUPABASE CONFIG
========================================================= */

const SUPABASE_URL =
    "https://qmigyzxkvrodnfyvjkbr.supabase.co";

const SUPABASE_PUBLISHABLE_KEY =
    "sb_publishable_BfnmEqlXE1YpUJnjP__JvQ_-nLQiP4a";

const uploadSupabase =
    window.supabase.createClient(
        SUPABASE_URL,
        SUPABASE_PUBLISHABLE_KEY
    );


/* =========================================================
   END — SUPABASE CONFIG
========================================================= */


/* =========================================================
   START — ELEMENTS
========================================================= */

const uploadAttachmentBtn =
    document.getElementById("attachmentBtn");

const uploadAttachmentPanel =
    document.getElementById("attachmentPanel");

const uploadImageOption =
    document.getElementById("imageOption");

const uploadVideoOption =
    document.getElementById("videoOption");

const uploadViewOnceOption =
    document.getElementById("viewOnceOption");

const uploadImageInput =
    document.getElementById("imageInput");

const uploadVideoInput =
    document.getElementById("videoInput");


/* =========================================================
   END — ELEMENTS
========================================================= */


/* =========================================================
   START — UPLOAD STATE
========================================================= */

let uploadMode = "normal";

let uploadBusy = false;


/* =========================================================
   END — UPLOAD STATE
========================================================= */


/* =========================================================
   START — OPEN ATTACHMENT PANEL
========================================================= */

if (uploadAttachmentBtn) {

    uploadAttachmentBtn.addEventListener(
        "click",
        function () {

            if (!uploadAttachmentPanel) {
                return;
            }

            const isOpen =
                uploadAttachmentPanel.style.display !== "none";

            uploadAttachmentPanel.style.display =
                isOpen ? "none" : "flex";

        }
    );
}


/* =========================================================
   END — OPEN ATTACHMENT PANEL
========================================================= */


/* =========================================================
   START — IMAGE OPTION
========================================================= */

if (uploadImageOption) {

    uploadImageOption.addEventListener(
        "click",
        function () {

            uploadMode = "normal";

            if (uploadAttachmentPanel) {
                uploadAttachmentPanel.style.display = "none";
            }

            if (uploadImageInput) {
                uploadImageInput.value = "";
                uploadImageInput.click();
            }

        }
    );
}


/* =========================================================
   END — IMAGE OPTION
========================================================= */


/* =========================================================
   START — VIDEO OPTION
========================================================= */

if (uploadVideoOption) {

    uploadVideoOption.addEventListener(
        "click",
        function () {

            uploadMode = "normal";

            if (uploadAttachmentPanel) {
                uploadAttachmentPanel.style.display = "none";
            }

            if (uploadVideoInput) {
                uploadVideoInput.value = "";
                uploadVideoInput.click();
            }

        }
    );
}


/* =========================================================
   END — VIDEO OPTION
========================================================= */


/* =========================================================
   START — VIEW ONCE OPTION
========================================================= */

if (uploadViewOnceOption) {

    uploadViewOnceOption.addEventListener(
        "click",
        function () {

            if (uploadAttachmentPanel) {
                uploadAttachmentPanel.style.display = "none";
            }

            /*
             * المستخدم اختار مشاهدة مرة.
             * نعرض اختيار الصورة أو الفيديو.
             */

            uploadMode = "view_once";

            if (uploadImageInput) {
                uploadImageInput.value = "";
                uploadImageInput.click();
            }

        }
    );
}


/* =========================================================
   END — VIEW ONCE OPTION
========================================================= */


/* =========================================================
   START — IMAGE SELECT
========================================================= */

if (uploadImageInput) {

    uploadImageInput.addEventListener(
        "change",
        async function () {

            const file =
                this.files && this.files[0];

            if (!file) {
                return;
            }

            try {

                await handleSelectedFile(
                    file,
                    "image",
                    uploadMode
                );

            } catch (error) {

                console.error(
                    "IMAGE UPLOAD ERROR:",
                    error
                );

                showUploadMessage(
                    "تعذر رفع الصورة."
                );

            }

            this.value = "";

        }
    );
}


/* =========================================================
   END — IMAGE SELECT
========================================================= */


/* =========================================================
   START — VIDEO SELECT
========================================================= */

if (uploadVideoInput) {

    uploadVideoInput.addEventListener(
        "change",
        async function () {

            const file =
                this.files && this.files[0];

            if (!file) {
                return;
            }

            try {

                await handleSelectedFile(
                    file,
                    "video",
                    uploadMode
                );

            } catch (error) {

                console.error(
                    "VIDEO UPLOAD ERROR:",
                    error
                );

                showUploadMessage(
                    "تعذر رفع الفيديو."
                );

            }

            this.value = "";

        }
    );
}


/* =========================================================
   END — VIDEO SELECT
========================================================= */


/* =========================================================
   START — HANDLE SELECTED FILE
========================================================= */

async function handleSelectedFile(
    file,
    mediaType,
    mode
) {

    if (uploadBusy) {
        return;
    }

    uploadBusy = true;


    try {

        /* ---------------------------------------------
           CHECK LOGIN
        --------------------------------------------- */

        const user =
            auth.currentUser;

        if (!user) {

            throw new Error(
                "USER_NOT_LOGGED_IN"
            );
        }


        /* ---------------------------------------------
           CHECK TYPE
        --------------------------------------------- */

        if (
            mediaType === "image" &&
            !file.type.startsWith("image/")
        ) {

            throw new Error(
                "INVALID_IMAGE"
            );
        }


        if (
            mediaType === "video" &&
            !file.type.startsWith("video/")
        ) {

            throw new Error(
                "INVALID_VIDEO"
            );
        }


        /* ---------------------------------------------
           CHECK SIZE
        --------------------------------------------- */

        const maxImageSize =
            15 * 1024 * 1024;

        const maxVideoSize =
            100 * 1024 * 1024;


        if (
            mediaType === "image" &&
            file.size > maxImageSize
        ) {

            throw new Error(
                "IMAGE_TOO_LARGE"
            );
        }


        if (
            mediaType === "video" &&
            file.size > maxVideoSize
        ) {

            throw new Error(
                "VIDEO_TOO_LARGE"
            );
        }


        /* ---------------------------------------------
           UPLOAD MESSAGE
        --------------------------------------------- */

        showUploadMessage(
            mediaType === "image"
                ? "جاري رفع الصورة..."
                : "جاري رفع الفيديو..."
        );


        /* ---------------------------------------------
           CREATE FILE PATH
        --------------------------------------------- */

        const extension =
            getFileExtension(file);


        const folder =
            mode === "view_once"
                ? "view-once"
                : "media";


        const filePath =
            `${folder}/${user.uid}/${Date.now()}_${randomString(10)}.${extension}`;


        /* ---------------------------------------------
           UPLOAD TO SUPABASE
        --------------------------------------------- */

        const {
            error: uploadError
        } =
            await uploadSupabase
                .storage
                .from("chat")
                .upload(
                    filePath,
                    file,
                    {
                        cacheControl: "3600",
                        upsert: false,
                        contentType: file.type
                    }
                );


        if (uploadError) {

            console.error(
                "SUPABASE STORAGE ERROR:",
                uploadError
            );

            throw uploadError;
        }


        /* ---------------------------------------------
           GET PUBLIC URL
        --------------------------------------------- */

        const {
            data: publicData
        } =
            uploadSupabase
                .storage
                .from("chat")
                .getPublicUrl(filePath);


        const publicUrl =
            publicData &&
            publicData.publicUrl;


        if (!publicUrl) {

            throw new Error(
                "PUBLIC_URL_NOT_FOUND"
            );
        }


        /* ---------------------------------------------
           CREATE MEDIA DATA
        --------------------------------------------- */

        const mediaData = {

            type: mediaType,

            url: publicUrl,

            path: filePath,

            fileName: file.name,

            mimeType: file.type,

            fileSize: file.size,

            viewOnce:
                mode === "view_once",

            opened: false,

            createdAt:
                firebase.firestore.FieldValue.serverTimestamp()

        };


        /* ---------------------------------------------
           SEND TO CHAT.JS
        --------------------------------------------- */

        if (
            typeof window.addMediaMessage ===
            "function"
        ) {

            await window.addMediaMessage(
                mediaData
            );

        } else {

            /*
             * fallback:
             * نضع الحدث حتى يستطيع chat.js
             * التقاط الملف إذا تم تحميله بعد upload.js.
             */

            window.dispatchEvent(
                new CustomEvent(
                    "chatMediaReady",
                    {
                        detail: mediaData
                    }
                )
            );

        }


        showUploadMessage(
            "تم إرسال الملف ✓"
        );


    } finally {

        uploadBusy = false;

        uploadMode = "normal";

    }

}


/* =========================================================
   END — HANDLE SELECTED FILE
========================================================= */


/* =========================================================
   START — ADD MEDIA MESSAGE
========================================================= */

async function addMediaMessage(
    mediaData
) {

    const user =
        auth.currentUser;

    if (!user) {
        throw new Error(
            "USER_NOT_LOGGED_IN"
        );
    }


    /*
     * chat.js يستطيع استبدال هذه الدالة
     * أو استخدام الحدث مباشرة.
     */

    const messageData = {

        uid: user.uid,

        senderId: user.uid,

        text: "",

        type: "media",

        mediaType:
            mediaData.type,

        mediaUrl:
            mediaData.url,

        mediaPath:
            mediaData.path,

        fileName:
            mediaData.fileName,

        mimeType:
            mediaData.mimeType,

        fileSize:
            mediaData.fileSize,

        viewOnce:
            mediaData.viewOnce,

        opened:
            false,

        createdAt:
            firebase.firestore.FieldValue.serverTimestamp()

    };


    /*
     * إذا كان chat.js يحتوي على دالة
     * لإرسال الرسائل نستخدمها.
     */

    if (
        typeof window.saveChatMessage ===
        "function"
    ) {

        await window.saveChatMessage(
            messageData
        );

        return;
    }


    /*
     * fallback مباشر إلى Firestore.
     */

    await db
        .collection("messages")
        .add(
            messageData
        );

}


/* =========================================================
   END — ADD MEDIA MESSAGE
========================================================= */


/* =========================================================
   START — CUSTOM EVENT
========================================================= */

window.addEventListener(
    "chatMediaReady",
    async function (event) {

        if (
            !event ||
            !event.detail
        ) {
            return;
        }


        try {

            await addMediaMessage(
                event.detail
            );

        } catch (error) {

            console.error(
                "MEDIA MESSAGE SAVE ERROR:",
                error
            );

            showUploadMessage(
                "تم رفع الملف ولكن تعذر إرسال الرسالة."
            );

        }

    }
);


/* =========================================================
   END — CUSTOM EVENT
========================================================= */


/* =========================================================
   START — HELPERS
========================================================= */

function getFileExtension(file) {

    const name =
        file.name || "";

    const parts =
        name.split(".");

    if (
        parts.length < 2
    ) {

        return "bin";
    }

    return parts
        .pop()
        .toLowerCase()
        .replace(
            /[^a-z0-9]/gi,
            ""
        ) || "bin";

}


function randomString(length) {

    const chars =
        "abcdefghijklmnopqrstuvwxyz0123456789";

    let result = "";

    for (
        let i = 0;
        i < length;
        i++
    ) {

        result +=
            chars.charAt(
                Math.floor(
                    Math.random() *
                    chars.length
                )
            );

    }

    return result;

}


/* =========================================================
   END — HELPERS
========================================================= */


/* =========================================================
   START — UPLOAD MESSAGE
========================================================= */

function showUploadMessage(
    message
) {

    /*
     * نحاول استخدام profileMessage إن وجد،
     * أو ننشئ إشعارًا بسيطًا للشات.
     */

    const existing =
        document.getElementById(
            "profileMessage"
        );

    if (existing) {

        existing.textContent =
            message;

        return;
    }


    let toast =
        document.getElementById(
            "uploadToast"
        );


    if (!toast) {

        toast =
            document.createElement(
                "div"
            );

        toast.id =
            "uploadToast";

        toast.style.position =
            "fixed";

        toast.style.left =
            "50%";

        toast.style.bottom =
            "90px";

        toast.style.transform =
            "translateX(-50%)";

        toast.style.zIndex =
            "99999";

        toast.style.padding =
            "10px 18px";

        toast.style.borderRadius =
            "14px";

        toast.style.background =
            "rgba(20,20,25,.95)";

        toast.style.color =
            "#fff";

        toast.style.fontSize =
            "14px";

        toast.style.boxShadow =
            "0 8px 30px rgba(0,0,0,.35)";

        document.body.appendChild(
            toast
        );

    }


    toast.textContent =
        message;

    toast.style.display =
        "block";


    clearTimeout(
        toast._timer
    );


    toast._timer =
        setTimeout(
            function () {

                toast.style.display =
                    "none";

            },
            2500
        );

}


/* =========================================================
   END — UPLOAD MESSAGE
========================================================= */


/* =========================================================
   UPLOAD.JS
   END OF FILE
========================================================= */